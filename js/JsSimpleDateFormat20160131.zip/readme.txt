To see the documentation, open JsSimpleDateFormat-Manual.html
To see the demo of the use of JsSimpleDateFormat, open JsSimpleDateFormat-demo.html
Find the latest version at https://github.com/atmulyana/bootstrap-datepicker (It's a part of that project, find the appropriate file)