To see the documentation, open JsSimpleDateFormat-Manual.html
To see the demo of the JsSimpleDateFormat use, open JsSimpleDateFormat-demo.html
Find the latest version at http://sourceforge.net/projects/jstable (It's a part of that project, find the appropriate file)